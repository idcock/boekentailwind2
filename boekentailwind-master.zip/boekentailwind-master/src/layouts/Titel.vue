<template>
  <header class="bg-blue-400 p-4 shadow-md">
    <span class="text-white text-2xl font-semibold uppercase tracking-wider">
      Boeken
    </span>
  </header>
</template>

<script>
export default {
  name: "Titel"
};
</script>

<style></style>
